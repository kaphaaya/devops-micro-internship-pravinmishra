---
name: ansible-risk-review
description: Run the read-only Ansible --check/--diff dry-run wrapper, analyze which tasks would change and why that's risky, and recommend whether it is safe to run the playbook for real. Never runs the playbook without --check.
allowed-tools: Bash, Read, Grep
disable-model-invocation: true
---

# Ansible Change Risk Review Skill

When `/ansible-risk-review` is invoked:

1. Read `CLAUDE.md` before doing anything else.
2. Run `bash ansible-check-review.sh || true`. This script only ever calls
   `ansible-playbook ... --check --diff` — a dry run that makes no real
   changes on any host.
3. Read `reports/ansible-risk-report.txt` and `reports/ansible-check-raw.txt`.
4. Report the following:
   - Overall status (HEALTHY, WARN, or FAIL)
   - Every changed task, quoted from the report
   - Which changed tasks are flagged as risky (service restarts, firewall
     rules, user/sudo changes, package or file removal) and why that
     category is risky to apply blindly
   - The most likely real-world impact if this playbook were applied as-is
   - One clear recommendation: safe to apply now, or hold for human review
5. If no changes were detected, clearly state that the playbook is a no-op
   against current state and applying it is low risk.
6. Do not edit files.
7. Do not use sudo.
8. Never run `ansible-playbook` without `--check`.
9. Never apply, converge, or "fix" anything yourself.
10. Ask the human to review the report and run the real `ansible-playbook`
    command themselves if they decide to proceed.
